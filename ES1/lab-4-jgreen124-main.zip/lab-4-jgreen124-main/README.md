There are two xdc files in this repo - one for the regular zybo and the other for the zybo z7. 

The vga was done on the regular zybo and the hdmi was done on the z7
